import CanvasJSReact from './canvajs/canvasjs.react'
var React = require('react');
var Component = React.Component;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;
 

const subscription = {
  type : "subscribe",
  product_ids : [
    "BTC-USD"
  ],
  channels : [
    {
        "name": "ticker",
        "product_ids": [
            "BTC-USD",
        ]
    }
  ]
}

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      datapoints : [],
    }
  }

  ws = new WebSocket("wss://ws-feed.pro.coinbase.com");

  componentDidMount = () => {
    var chart = this.chart;
    this.ws.onopen = () => {
      this.ws.send(JSON.stringify(subscription))
    }
    this.ws.onmessage = (message) => {
      const data = JSON.parse(message.data);
      let datapoints = this.state.datapoints;
      if(data.type == 'ticker'){
        datapoints.push({
          x : new Date(data.time),
          y : Math. trunc(data.price)
        })
      }
      this.setState({datapoints : datapoints});
      chart.render();
    }
  }

	render() {
    console.log(this.state.datapoints)
		const options = {
			theme: "light2",
			title: {
				text: "BTC_USD"
			},
			axisY: {
				title: "Prices",
				prefix: "",
				includeZero: false
			},
			data: [{
				type: "line",
				xValueFormatString: "MMM YYYY",
				dataPoints: this.state.datapoints
			}]
		}
		return (
      <div>
        <CanvasJSChart options = {options} 
          onRef={ref => this.chart = ref}
        />
      </div>
		);
	}
}
 
export default App;
